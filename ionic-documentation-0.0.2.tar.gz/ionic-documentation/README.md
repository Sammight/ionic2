# Ionic v1 Documetation

## Running

wget https://github.com/abakasam/ionic/archive/refs/tags/ionic-documentation-0.0.2.tar.gz
tar -xvf ionic-documentation-0.0.2.tar.gz
cd ionic-documentation
node server.js
http://localhost:3000



## Contents
Section | Link
--------|------
Command Line | https://aquaogen-ionic-docs.herokuapp.com/CLI/ionicframework.com/docs/v3/cli/index.html
Documentation | https://aquaogen-ionic-docs.herokuapp.com/Docs/ionicframework.com/docs/v1/index.html
Cordova | /Cordova
Architecture | /Architecture
AngularJS | /AngularJS
Example | /Example
